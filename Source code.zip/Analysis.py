import pandas as pd
import requests
from bs4 import BeautifulSoup


def read_source_file():
        file = open("./otu_reps.fasta")
        lines = file.readlines()
        data_lines =[]
        line_text =[]
        for index, line in enumerate(lines, start=1):
                line_text.extend(line.split())
                if index % 2 == 0:
                        data_lines.append(line_text)
                        line_text=[]
        return data_lines
def get_tables(s):

        url = "http://www.boldsystems.org/index.php/IDS_IdentificationRequest"
        data = {"tabtype":"animalTabPane",
                "historicalDB":"",
                "searchdb":"COX1_SPECIES",
                "sequence":s}
        res = requests.post(url=url, data=data)


        con = BeautifulSoup(res.text, "html.parser")
        token = ""

        for item in con.find_all('input', attrs={"name": "idToken"}):
                token = item.get('value')


        real_url = "http://www.boldsystems.org/index.php/IDS_SingleResult?token=" + token

        con = requests.get(real_url)

        real_con = BeautifulSoup(con.text, "html.parser")


        tables = real_con.find_all("table", attrs={"class": "table resultsTable noborder"})
        tables.reverse()
        return tables



def do_table(table):
        data = []
        tds = table.find_all("td")
        line = []
        for index, td in enumerate(tds, start=1):
                line.append(td.text.strip())
                if index % 9 == 0:
                        data.append(line)
                        line = []
        return data


def get_col(data, col_inde=None):
        r = []
        for item in data:
                r.append(item[col_inde])
        return r


def get_diff_count(data):
        data = list(set(data))
        if len(data) > 1:
                return False
        else:
                return True


def filter_data(data):

        data1 = list(filter(lambda x: float(x[7]) > 98.5, data))
        if len(data1) !=0:
                ready = data1[0]
                condition = []
                for i in range(6):
                    r = get_diff_count(get_col(data1, col_inde=i))
                    condition.append(r)
                data1 = list(zip(ready, condition))
                data1 = list(filter(lambda x:x[1], data1))
                data1 = list(map(lambda x: x[0], data1))
                return data1
        else:
                data = list(filter(lambda x: float(x[7]) > 97.5, data))
                if len(data) == 0:
                        return None
                else:
                        ready = data[0][:4]
                        condition = []
                        for i in range(4):
                                r = get_diff_count(get_col(data, col_inde=i))
                                condition.append(r)
                        data = list(zip(ready, condition))
                        data = list(filter(lambda x: x[1], data))
                        data = list(map(lambda x: x[0], data))
                        return data

start = 0

source = read_source_file()
for index, item in enumerate(source[start:], start=start):
        tables = get_tables(item[2])
        for table in tables:
                data = do_table(table)
                del data[0]
                data = filter_data(data)
                if data == None:
                        print("这是第 ",index,"条， 这一条可能有问题！")
                        print("check this :", item[2])
                        break
                s_id = item[0][1:]
                data = [[s_id] + data]
                pd.DataFrame(data).to_csv("./"+str(s_id)+".csv", index=None, header=None)
                print("done ", index, s_id, " !")
                break









